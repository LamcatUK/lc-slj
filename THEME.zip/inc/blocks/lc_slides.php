<section class="slides">
    <div class="container-xl d-flex flex-wrap justify-content-center">
        <img src="<?=get_stylesheet_directory_uri()?>/img/slides-left.png"
            alt="">
        <img src="<?=get_stylesheet_directory_uri()?>/img/slides-right.png"
            alt="">
    </div>
</section>