<section class="contact_form has-slj-light-background-color py-5">
    <div class="container-xl">
        <div class="row justify-content-center mx-md-0">
            <div class="col-md-8 col-lg-6">
                <h2>Enquiry form</h2>
                <?=do_shortcode('[contact-form-7 id="' . get_field('form_id') . '" title="Enquiry form"]')?>
                <p>Required fields*</p>
            </div>
        </div>
    </div>
</section>