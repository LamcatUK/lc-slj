<section class="three_images__container">
<?php
    if (get_field('container')) {
        echo '<div class="container-xl">';
    }
    ?>
<div class="three_images">
    <?=wp_get_attachment_image(get_field('image_one'), 'full')?>
    <?=wp_get_attachment_image(get_field('image_two'), 'full')?>
    <?=wp_get_attachment_image(get_field('image_three'), 'full')?>
</div>
<?php
    if (get_field('container')) {
        echo '</div>';
    }
    ?>
</section>